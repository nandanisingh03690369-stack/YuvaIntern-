# Datasets

Download these from Kaggle and place them in this folder with these exact names:

| File name          | Dataset                  | Used in      |
|--------------------|--------------------------|--------------|
| `titanic.csv`      | Titanic (train.csv)      | Week 1, 2, 5 |
| `iris.csv`         | Iris Species             | Week 3, 6    |
| `house_prices.csv` | House Prices (train.csv) | Week 4       |

Raw CSVs are git-ignored to keep the repo small.
